import { readFile } from 'node:fs/promises'
import { expect, test } from '@playwright/test'
import { PDFCheckBox, PDFDocument, PDFTextField } from 'pdf-lib'

// Any PDF can be tried, such as a form that failed for someone, before and after a fix.
const formPath = process.env.OFFEE_E2E_FORM ?? 'apps/web/public/samples/tenant-self-disclosure.pdf'

const profile = {
  label: 'End to end (fictional)',
  firstName: 'Erika',
  lastName: 'Mustermann',
  role: 'Engineer',
  organization: 'Beispiel GmbH',
  email: 'erika@example.org',
  phone: '+49 30 1234567',
  street: 'Musterstraße 1',
  postalCode: '10115',
  city: 'Berlin',
  country: 'Germany',
  languages: ['German', 'English'],
  tone: '',
  facts: 'Date of birth: 12.08.1984\nPlace of birth: Köln\nNationality: German',
  signatureImage: null,
}

const idOf = (body: unknown): string => (typeof body === 'object' && body !== null && 'id' in body && typeof body.id === 'string' ? body.id : '')

test('fills a PDF form end to end with the local model', async ({ page, baseURL }) => {
  const created = await page.request.post('/api/profiles', { headers: { origin: baseURL ?? '' }, data: profile })
  expect(created.ok()).toBe(true)
  const profileId = idOf(await created.json())
  await page.addInitScript((context) => localStorage.setItem('offee.workContext', context), JSON.stringify({ profileId, personaId: null }))

  await page.goto('/forms')
  await page.locator('input[type=file]').setInputFiles(formPath)
  await expect(page.getByText('Check every value')).toBeVisible({ timeout: 60 * 60_000 })
  await test.info().attach('review', { body: await page.screenshot({ fullPage: true }), contentType: 'image/png' })

  await page.getByRole('button', { name: 'Save filled', exact: true }).click()
  const download = page.waitForEvent('download')
  await page.getByRole('link', { name: 'Download the PDF' }).click({ timeout: 5 * 60_000 })
  const filledPath = await (await download).path()
  await test.info().attach('filled.pdf', { path: filledPath, contentType: 'application/pdf' })

  const fields = (await PDFDocument.load(await readFile(filledPath))).getForm().getFields()
  const filledCount = fields.filter((field) => (field instanceof PDFTextField && (field.getText() ?? '') !== '') || (field instanceof PDFCheckBox && field.isChecked())).length
  test.info().annotations.push({ type: 'fields', description: `${filledCount} of ${fields.length} fields filled` })
  expect(filledCount).toBeGreaterThan(0)
})
